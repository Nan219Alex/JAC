<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- logo navigation -->
    <link rel="icon" href="img/core-img/uici.ico">
    <!-- Titre -->
    <title>Espace Etudiants</title>
    <!-- Lien css -->
    <link rel="stylesheet" href="style.css">

</head>
<body>
    
    <!-- #### Menu #### -->
    <?php require 'menu.php'; ?>


    <!-- ##### Nom de filière ##### -->
    <div class="clever-catagory bg-img d-flex align-items-center justify-content-center p-3" style="background-image: url(img/bg-img/bc2.jpg);">
        <h3>
            <span style="color: #28a745;">UICI</span><span style="color: #000;text-transform: none;">-online</span>
            <br /> <small style="font-style: italic;">En savoir +</small>
        </h3>
    </div>


    <!-- ##### Début à propos de nous ##### -->
    <div class="regular-page-area section-padding-100">
        <div class="container">
            <div class="row" >
                <div class="col-12">
                    <div class="page-content">
                        <h4>En savoir plus sur notre plateforme </h4>
                        <p>
                           <span style="color: #28a745;">UICI</span><span style="color: #000;">-online</span>, une plateforme chargée de dispensée les cours en ligne, cette plateforme a été créée par les etudiants en faculté ISN (Informatique et Sciences du Numériques ) avec la collaboration des étudiants en faculté de SEG (Science Economique et de Gestion) de l'Université Internationale de Côte d'Ivoire. Ainsi cette plateforme à pour objective d'assurer et faciliter les cours à l'UICI. La plateforme est accessible à tous les étudiants de chaque     faculté, et de chaque niveau.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### Fin à propos de nous ##### -->

   <!-- #### footer #### -->
   <?php require 'footer.php'; ?>

    <!-- ##### Tous les scripts Js ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
</body>

</html>