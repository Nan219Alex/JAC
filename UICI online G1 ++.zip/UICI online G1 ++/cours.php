<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- logo navigation -->
    <link rel="icon" href="img/core-img/uici.ico">
    <!-- Titre -->
    <title>Espace Etudiants</title>
    <!-- Stylesheet -->
    <link rel="stylesheet" href="style.css">

</head>
<body>
   
<!-- #### Menu #### -->
<?php require 'menu.php'; ?>

    <!-- ##### Nom de filière ##### -->
    <div class="clever-catagory bg-img d-flex align-items-center justify-content-center p-3" style="background-image: url(img/bg-img/bc2.jpg);">
        <h3>
            Licence 2<br /> <small style="font-style: italic;">Informatique & Science du Numérique</small>
        </h3>
    </div>

    <!-- ##### tous les cours publiés ##### -->
    <section class="popular-courses-area section-padding-100">
        <div class="container">
            <div class="row">
                <!-- Cour unique -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-popular-course mb-100 wow fadeInUp" data-wow-delay="250ms">
                      <a href="le_cour.php"> <img src="img/bg-img/bg.jpg" alt=""></a> 
                        <!-- Contenu du cour -->
                        <div class="course-content">
                            <h4>Objective C</h4>
                            <div class="meta d-flex align-items-center">
                                <a href="#">Dr Traoré</a>
                                <span><i class="fa fa-circle" aria-hidden="true"></i></span>
                                <a href="#">Programmation</a>
                            </div>
                            <p>
                                Vous avez la possibilité de lire ou de télécharger le cour.
                            </p>
                        </div>
                        
                        <div class="seat-rating-fee d-flex justify-content-between">
                            <div class="seat-rating h-100 d-flex align-items-center">
                                <div class="rating">
                                    le 24/03/2020 à 15h50&nbsp; &nbsp;
                                    <a href="test.pdf" download="test.pdf"><i class="fa fa-download" title="Télécharger le cour"></i></a>
                                </div>
                            </div>
                            <div class="course-fee h-100">
                                <a href="le_cour.php" class="free">Débuter</a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Cour unique -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-popular-course mb-100 wow fadeInUp" data-wow-delay="250ms">
                      <a href="le_cour.php"> <img src="img/bg-img/bg.jpg" alt=""></a> 
                        <!-- Contenu du cour -->
                        <div class="course-content">
                            <h4>Objective C</h4>
                            <div class="meta d-flex align-items-center">
                                <a href="#">Dr Traoré</a>
                                <span><i class="fa fa-circle" aria-hidden="true"></i></span>
                                <a href="#">Programmation</a>
                            </div>
                            <p>
                                Vous avez la possibilité de lire ou de télécharger le cour.
                            </p>
                        </div>
                        <!-- Seat Rating Fee -->
                        <div class="seat-rating-fee d-flex justify-content-between">
                            <div class="seat-rating h-100 d-flex align-items-center">
                                <div class="rating">
                                    le 24/03/2020 à 15h50&nbsp; &nbsp;
                                    <a href="test.pdf" download="test.pdf"><i class="fa fa-download" title="Télécharger le cour"></i></a>
                                </div>
                            </div>
                            <div class="course-fee h-100">
                                <a href="le_cour.php" class="free">Débuter</a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Cour unique -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-popular-course mb-100 wow fadeInUp" data-wow-delay="250ms">
                      <a href="le_cour.php"> <img src="img/bg-img/bg.jpg" alt=""></a> 
                        <!-- Contenu du cour -->
                        <div class="course-content">
                            <h4>Objective C</h4>
                            <div class="meta d-flex align-items-center">
                                <a href="#">Dr Traoré</a>
                                <span><i class="fa fa-circle" aria-hidden="true"></i></span>
                                <a href="#">Programmation</a>
                            </div>
                            <p>
                                Vous avez la possibilité de lire ou de télécharger le cour.
                            </p>
                        </div>
                        <!-- Seat Rating Fee -->
                        <div class="seat-rating-fee d-flex justify-content-between">
                            <div class="seat-rating h-100 d-flex align-items-center">
                                <div class="rating">
                                    le 24/03/2020 à 15h50&nbsp; &nbsp;
                                    <a href="test.pdf" download="test.pdf"><i class="fa fa-download" title="Télécharger le cour"></i></a>
                                </div>
                            </div>
                            <div class="course-fee h-100">
                                <a href="le_cour.php" class="free">Débuter</a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Cour unique -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-popular-course mb-100 wow fadeInUp" data-wow-delay="250ms">
                      <a href="le_cour.php"> <img src="img/bg-img/bg.jpg" alt=""></a> 
                        <!-- Contenu du cour -->
                        <div class="course-content">
                            <h4>Objective C</h4>
                            <div class="meta d-flex align-items-center">
                                <a href="#">Dr Traoré</a>
                                <span><i class="fa fa-circle" aria-hidden="true"></i></span>
                                <a href="#">Programmation</a>
                            </div>
                            <p>
                                Vous avez la possibilité de lire ou de télécharger le cour.
                            </p>
                        </div>
                        <!-- Seat Rating Fee -->
                        <div class="seat-rating-fee d-flex justify-content-between">
                            <div class="seat-rating h-100 d-flex align-items-center">
                                <div class="rating">
                                    le 24/03/2020 à 15h50&nbsp; &nbsp;
                                    <a href="test.pdf" download="test.pdf"><i class="fa fa-download" title="Télécharger le cour"></i></a>
                                </div>
                            </div>
                            <div class="course-fee h-100">
                                <a href="le_cour.php" class="free">Débuter</a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Cour unique -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-popular-course mb-100 wow fadeInUp" data-wow-delay="250ms">
                      <a href="le_cour.php"> <img src="img/bg-img/bg.jpg" alt=""></a> 
                        <!-- Contenu du cour -->
                        <div class="course-content">
                            <h4>Objective C</h4>
                            <div class="meta d-flex align-items-center">
                                <a href="#">Dr Traoré</a>
                                <span><i class="fa fa-circle" aria-hidden="true"></i></span>
                                <a href="#">Programmation</a>
                            </div>
                            <p>
                                Vous avez la possibilité de lire ou de télécharger le cour.
                            </p>
                        </div>
                        <!-- Seat Rating Fee -->
                        <div class="seat-rating-fee d-flex justify-content-between">
                            <div class="seat-rating h-100 d-flex align-items-center">
                                <div class="rating">
                                    le 24/03/2020 à 15h50&nbsp; &nbsp;
                                    <a href="test.pdf" download="test.pdf"><i class="fa fa-download" title="Télécharger le cour"></i></a>
                                </div>
                            </div>
                            <div class="course-fee h-100">
                                <a href="le_cour.php" class="free">Débuter</a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Cour unique -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-popular-course mb-100 wow fadeInUp" data-wow-delay="250ms">
                      <a href="le_cour.php"> <img src="img/bg-img/bg.jpg" alt=""></a> 
                        <!-- Contenu du cour -->
                        <div class="course-content">
                            <h4>Objective C</h4>
                            <div class="meta d-flex align-items-center">
                                <a href="#">Dr Traoré</a>
                                <span><i class="fa fa-circle" aria-hidden="true"></i></span>
                                <a href="#">Programmation</a>
                            </div>
                            <p>
                                Vous avez la possibilité de lire ou de télécharger le cour.
                            </p>
                        </div>
                        <!-- Seat Rating Fee -->
                        <div class="seat-rating-fee d-flex justify-content-between">
                            <div class="seat-rating h-100 d-flex align-items-center">
                                <div class="rating">
                                    le 24/03/2020 à 15h50&nbsp; &nbsp;
                                    <a href="test.pdf" download="test.pdf"><i class="fa fa-download" title="Télécharger le cour"></i></a>
                                </div>
                            </div>
                            <div class="course-fee h-100">
                                <a href="le_cour.php" class="free">Débuter</a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Cour unique -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-popular-course mb-100 wow fadeInUp" data-wow-delay="250ms">
                      <a href="le_cour.php"> <img src="img/bg-img/bg.jpg" alt=""></a> 
                        <!-- Contenu du cour -->
                        <div class="course-content">
                            <h4>Objective C</h4>
                            <div class="meta d-flex align-items-center">
                                <a href="#">Dr Traoré</a>
                                <span><i class="fa fa-circle" aria-hidden="true"></i></span>
                                <a href="#">Programmation</a>
                            </div>
                            <p>
                                Vous avez la possibilité de lire ou de télécharger le cour.
                            </p>
                        </div>
                        <!-- Seat Rating Fee -->
                        <div class="seat-rating-fee d-flex justify-content-between">
                            <div class="seat-rating h-100 d-flex align-items-center">
                                <div class="rating">
                                    le 24/03/2020 à 15h50&nbsp; &nbsp;
                                    <a href="test.pdf" download="test.pdf"><i class="fa fa-download" title="Télécharger le cour"></i></a>
                                </div>
                            </div>
                            <div class="course-fee h-100">
                                <a href="le_cour.php" class="free">Débuter</a>
                            </div>
                        </div>
                    </div>
                </div>

               <!-- Cour unique -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-popular-course mb-100 wow fadeInUp" data-wow-delay="250ms">
                      <a href="le_cour.php"> <img src="img/bg-img/bg.jpg" alt=""></a> 
                        <!-- Contenu du cour -->
                        <div class="course-content">
                            <h4>Objective C</h4>
                            <div class="meta d-flex align-items-center">
                                <a href="#">Dr Traoré</a>
                                <span><i class="fa fa-circle" aria-hidden="true"></i></span>
                                <a href="#">Programmation</a>
                            </div>
                            <p>
                                Vous avez la possibilité de lire ou de télécharger le cour.
                            </p>
                        </div>
                        <!-- Seat Rating Fee -->
                        <div class="seat-rating-fee d-flex justify-content-between">
                            <div class="seat-rating h-100 d-flex align-items-center">
                                <div class="rating">
                                    le 24/03/2020 à 15h50&nbsp; &nbsp;
                                    <a href="test.pdf" download="test.pdf"><i class="fa fa-download" title="Télécharger le cour"></i></a>
                                </div>
                            </div>
                            <div class="course-fee h-100">
                                <a href="le_cour.php" class="free">Débuter</a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Cour unique -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-popular-course mb-100 wow fadeInUp" data-wow-delay="250ms">
                      <a href="le_cour.php"> <img src="img/bg-img/bg.jpg" alt=""></a> 
                        <!-- Contenu du cour -->
                        <div class="course-content">
                            <h4>Objective C</h4>
                            <div class="meta d-flex align-items-center">
                                <a href="#">Dr Traoré</a>
                                <span><i class="fa fa-circle" aria-hidden="true"></i></span>
                                <a href="#">Programmation</a>
                            </div>
                            <p>
                                Vous avez la possibilité de lire ou de télécharger le cour.
                            </p>
                        </div>
                        <!-- Seat Rating Fee -->
                        <div class="seat-rating-fee d-flex justify-content-between">
                            <div class="seat-rating h-100 d-flex align-items-center">
                                <div class="rating">
                                    le 24/03/2020 à 15h50&nbsp; &nbsp;
                                    <a href="test.pdf" download="test.pdf"><i class="fa fa-download" title="Télécharger le cour"></i></a>
                                </div>
                            </div>
                            <div class="course-fee h-100">
                                <a href="le_cour.php" class="free">Débuter</a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
    </section>
    <!-- ##### Popular Course Area End ##### -->

<!-- #### Footer #### -->
<?php require 'footer.php'; ?>

    <br>

    <!-- ##### Tous les scripts Js ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
</body>

</html>