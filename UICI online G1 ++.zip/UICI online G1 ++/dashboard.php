<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- Titre -->
    <title>Espace Etudiants</title>

      <!-- logo navigation -->
    <link rel="icon" href="img/core-img/uici.ico">

    <!-- Stylesheet -->
    <link rel="stylesheet" href="style.css">
    <style>
        a{
            color: blue;
            text-decoration: underline;
        }
    </style>
</head>

<body>

<!-- ##### Barre de navigation ##### -->
<?php require 'menu.php'; ?>

    <!-- ##### Début de la zone Hero ##### -->
    <section class="hero-area bg-img bg-overlay-2by5" style="background-image: url(img/core-img/bg.jpg);background-position: center;">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <!-- Hero Contenu -->
                    <div class="hero-content text-center">
                        <h2>UICI-online</h2>
                        <small href="#" class="btn clever-btn">
                            Réservée uniquement aux étudiants d'UICI.
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ##### fin de la zone Hero ##### -->


    <!-- ##### Début zone de cours ##### -->
    <section class="popular-courses-area section-padding-100-0" style="background-image: url(img/core-img/texture.png);">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading">
                        <h3>Quelques cours</h3>
                        <hr class="trait" style="width: 150px;height: 2px;background-color: #1ee65d;margin: 0 auto;margin-top: 10px;">
                    </div>

                </div>
            </div>

            <div class="row">
                <!-- Quelques cours -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-popular-course mb-100">
                        <img src="img/bg-img/c1.jpg" alt="">
                        <!-- Contenudu cours -->
                        <div class="course-content">
                            <h5>Oracle</h5>
                            <div class="meta d-flex align-items-center">
                                <small><i><a href="">Prof:</a></i></small>
                                <a href="#">Dr. Stanilas</a>
                            </div>
                        </div>
                        <!-- Date de publication -->
                        <div class="seat-rating-fee d-flex justify-content-between">
                            <div class="seat-rating d-flex align-items-center">
                                 <div>
                                   <i>Pubié le 24/03/2020 </i>
                                </div>
                            </div>
                            <div class="course-fee">
                                <a href="#" class="free">09h00</a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Quelques cours -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-popular-course mb-100">
                        <img src="img/bg-img/c2.jpg" alt="">
                        <!-- Contenudu cours -->
                        <div class="course-content">
                            <h5>Développement d'application</h5>
                            <div class="meta d-flex align-items-center">
                                <small><i><a href="">Prof:</a></i></small>
                                <a href="#">Dr. N'Guessan Gérard</a>
                            </div>
                        </div>
                        <!-- Date de publication -->
                        <div class="seat-rating-fee d-flex justify-content-between">
                            <div class="seat-rating d-flex align-items-center">
                                 <div>
                                   <i>Pubié le 24/03/2020 </i>
                                </div>
                            </div>
                            <div class="course-fee">
                                <a href="#" class="free">09h00</a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Quelques cours -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-popular-course mb-100">
                        <img src="img/bg-img/c1.jpg" alt="">
                        <!-- Contenudu cours -->
                        <div class="course-content">
                            <h5>CyberSécurité</h5>
                            <div class="meta d-flex align-items-center">
                                <small><i><a href="">Prof:</a></i></small>
                                <a href="#">Dr. Traoré</a>
                            </div>
                        </div>
                        <!-- Date de publication -->
                        <div class="seat-rating-fee d-flex justify-content-between">
                            <div class="seat-rating d-flex align-items-center">
                                 <div>
                                   <i>Pubié le 24/03/2020 </i>
                                </div>
                            </div>
                            <div class="course-fee">
                                <a href="#" class="free">09h00</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ##### fin zone de cours ##### -->

    <!-- ##### Début consigne ##### -->
    <section class="register-now section-padding-100-0 d-flex align-items-center" style="background-image: url(img/core-img/texture.png);">

        <div class="register-now-countdown mb-100">
            <h3><u>Consigne</u></h3>
            <p>
                Pour tous soucis veuillez contactez l'administrateur en remplissant le formulaire présent dans le menu <a href="#">Contact</a>. <br>( soyez explicite ).<br>
                <b>
                    Vous pouvez échanger sur les différents cours dispensés par les professeurs. ( Dans le menu <a href="#">Cours</a>)                    
                </b>
            </p>
        </div>
    </section>
    <!-- ##### Fin consigne ##### -->

<!-- ##### Pied de page ##### -->
<?php require 'footer.php'; ?>

    <!-- ##### Tous les Scripts Js ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
</body>

</html>