<!-- ##### Début pied de page ##### -->
<footer class="footer-area">
    <!-- haut de pied de page -->
    <div class="top-footer-area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <!-- Footer Logo -->
                    <div class="footer-logo">
                        <a href="dashboard.php"><img src="img/core-img/logo.jpg" alt=""></a>
                    </div>
                    <!-- Droit d'écriture -->
                    <p><a href="#">
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | UICI-online <i class="fa fa-heart-o" aria-hidden="true"></i> from <a href="https:www.uici.info" target="_blank">UICI</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bottom Footer Area -->
    <div class="bottom-footer-area d-flex justify-content-between align-items-center">
        <!-- Contact Info -->
        <div class="contact-info">
            <a href="#"><span>Phone:</span> +225 07 314 314</a>
        </div>
        <!-- Nous suivre -->
        <div class="follow-us">
            <span>Nous suivre</span>
            <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
            <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
        </div>
    </div>
</footer>
<!-- ##### Fin pied de page ##### -->