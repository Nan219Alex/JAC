<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Login</title>
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <link rel="stylesheet" href="styles.css">
      <!-- logo navigation -->
    <link rel="icon" href="img/core-img/uici.ico">
    
  </head>
  <body>
  
  <div class="container">

    <div id="logo">
      <img src="img/core-img/logo1.jpg" alt="UICI-online">
    </div>
    
    <div>
      <form action="dashboard.php">

          <h1>
            Accéder à la plateforme
          </h1>
          <hr class="trait">

          <div class="rows">
              <div class="input-group mb-3 input-group-sm">
                <input type="text" class="form-control" placeholder="Matricule ici..." style="text-align: center;">
                <div class="input-group-append">
                   <span class="input-group-text">Matricule</span>
                </div>
              </div>
          </div>

          <div class="rows" style="margin-top: 10px;">
              <div class="input-group mb-3 input-group-sm">
                <input type="password" class="form-control" placeholder="Mot de passe ici..." style="text-align: center;">
                <div class="input-group-append">
                   <span class="input-group-text">Mot de passe</span>
                </div>
              </div>
             
          </div>

          <div class="rows" style="margin-top: 10px;">
            <div>
              <button class="btn btn-success form-control">
                Se Connecter
              </button>
            </div>
          </div>


      </form>
    </div>
    

  </div>

  </body>
</html>
