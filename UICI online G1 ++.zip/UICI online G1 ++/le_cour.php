<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- logo navigation -->
    <link rel="icon" href="img/core-img/uici.ico">
        <!-- Titre -->
    <title>Espace Etudiants</title>

      <!-- Favicon -->
      <link rel="icon" href="">

    <!-- Stylesheet -->
    <link rel="stylesheet" href="style.css">

</head>

<body>

    <!-- ##### Menu ##### -->
<?php require 'menu.php'; ?>

    <!-- ##### Début cour unique ##### -->
    <div class="single-course-intro d-flex align-items-center justify-content-center" style="background-image: url(img/bg-img/bg.jpg);">
        <!-- Contenu -->
        <div class="single-course-intro-content text-center">
            
            <h3>Python</h3>
            <div class="meta d-flex align-items-center justify-content-center">
                <a href="#">Dr. Traoré</a>
                <span><i class="fa fa-circle" aria-hidden="true"></i></span>
                <a href="#">Programmation</a><br>
            </div>
            <a href="download/test.pdf" target="_blank" style="border:1px solid #1ee65d;background-color: #1ee65d;padding:5px 10px;border-radius: 10px">
                Visualiser le cour
            </a>
        </div>
    </div>
    <!-- ##### Fin cour unique ##### -->

    <!-- ##### Début contenu cour ##### -->
    <div class="single-course-content section-padding-100">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-12">
                    <div class="course--content">

                        <div class="clever-tabs-content">
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="tab--1" data-toggle="tab" href="#tab1" role="tab" aria-controls="tab1" aria-selected="false">Description Du cour</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="tab--2" data-toggle="tab" href="#tab2" role="tab" aria-controls="tab5" aria-selected="true">Forum</a>
                                </li>
                            </ul>

                            <div class="tab-content" id="myTabContent">
                                <!-- Tab Text -->
                                <div class="tab-pane fade show active" id="tab1" role="tabpanel" aria-labelledby="tab--1">
                                    <div class="clever-description">

                                        <!-- A propos du cour -->
                                        <div class="about-course mb-30">
                                            <h4>A propos du cours</h4>
                                            <p>Python est un language de programmation orienté objet dont les syntaxe sont tres simple comparé au autre language de programmation.
                                            Python est un language de programmation orienté objet dont les syntaxe sont tres simple comparé au autre language de programmation.
                                            Python est un language de programmation orienté objet dont les syntaxe sont tres simple comparé au autre language de programmation.</p>
                                        </div>


                                    </div>
                                </div>

                                <!-- tab text -->
                                <div class="tab-pane fade" id="tab2" role="tabpanel" aria-labelledby="tab--2">
                                    <div class="clever-review">

                                        <!-- Vue seul -->
                                        <div class="single-review mb-30">
                                            <div class="d-flex justify-content-between mb-30">
                                                <!-- Vue admin -->
                                                <div class="review-admin d-flex">
                                                    <div class="thumb">
                                                        <img src="img/bg-img/t1.png" alt="">
                                                    </div>
                                                    <div class="text">
                                                        <h6>Koffi Koffi</h6>
                                                        <span>29 Sep 2017 à 9:48</span>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce enim nulla, mollis eu metus in, sagittis.</p>
                                        </div>

                                        <!-- Vue seul -->
                                        <div class="single-review mb-30">
                                            <div class="d-flex justify-content-between mb-30">
                                                <!-- Vue Admin -->
                                                <div class="review-admin d-flex">
                                                    <div class="thumb">
                                                        <img src="img/bg-img/t1.png" alt="">
                                                    </div>
                                                    <div class="text">
                                                        <h6>Azerty Qwerty</h6>
                                                        <span>29 Sep 2017 à 19:48</span>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce enim nulla, mollis eu metus in, sagittis.</p>

                                        </div>
                                        <div class="col-6 col-md-6 col-lg-6" style="margin: 0 auto;">
                                            <form action="">
                                                <div class="col-md-12">
                                                <textarea name="message" id="" cols="20" rows="3" class="form-control" placeholder="Taper messages ici..."></textarea>
                                                </div>
                                                <div class="col-md-12" style="margin-top: 10px;">
                                                <button type="" class="btn btn-info form-control">Envoyer</button>
                                                </div>           
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                        
                    

                </div>
            </div>
        </div>
    </div>
    <!-- ##### Fin contenu cour ##### -->

<!-- ##### Footer ##### -->
<?php require 'footer.php'; ?>
    <br>
    <!-- ##### Footer Area End ##### -->

    <!-- ##### Tous les Scripts Js ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
</body>

</html>