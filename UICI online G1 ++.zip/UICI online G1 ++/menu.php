<!-- Prechargement -->
<div id="preloader">
    <div class="spinner"></div>
</div>

<!-- ##### Début de la zone header ##### -->
<header class="header-area">

    <!-- zone de navbar -->
    <div class="clever-main-menu">
        <div class="classy-nav-container breakpoint-off">
            <!-- Menu -->
            <nav class="classy-navbar justify-content-between" id="cleverNav">

                <!-- Logo -->
                <a class="nav-brand" href="dashboard.php">
                    <img src="img/core-img/logo1.jpg" alt="UICI-online">
                </a>

                <!-- Barre de navigation -->
                <div class="classy-navbar-toggler">
                    <span class="navbarToggler"><span></span><span></span><span></span></span>
                </div>

                <!-- Menu -->
                <div class="classy-menu">

                    <!-- Bouton fermer -->
                    <div class="classycloseIcon">
                        <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                    </div>

                    <!-- Début nav -->
                    <div class="classynav">
                        <ul>
                            <li><a href="dashboard.php">Accueil</a></li>
                            <li><a href="cours.php">Cours</a></li>
                            <li><a href="about.php">En savoir plus</a></li>
                            <li><a href="contact.php">Contact</a></li>
                        </ul>

                       
                        <!-- icône utilisateur -->
                        <div class="login-state d-flex align-items-center" style="margin-left: 20px;">
                            <div class="user-name mr-30">
                                <div class="dropdown">
                                    <a class="dropdown-toggle" href="#" role="button" id="userName" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <img src="img/bg-img/bc1.jpg" style="min-width: 40px;max-width: 40px;min-height: 40px;max-height: 40px" alt="user" class="rounded-circle">
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userName">
                                        <a class="dropdown-item" href="profil.php">Profil</a>
                                        <a class="dropdown-item" href="index.php">
                                            Déconnexion
                                        </a>
                                    </div>
                                </div>
                            </div>
                           
                        </div>

                    </div>
                    <!-- Fin Nav -->
                </div>
            </nav>
        </div>
    </div>
</header>
<!-- ##### Fin de la zone header ##### -->