<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- logo navigation -->
    <link rel="icon" href="img/core-img/uici.ico">
    <!-- Titre -->
    <title>Espace Etudiants</title>
    <!-- Stylesheet -->
    <link rel="stylesheet" href="style.css">
    <style>
        .trait{
            width: 100px;
            height: 2px;
            background-color: #1ee65d;
        }
        .etoile{
            color:red;
        }
    </style>
</head>
<body>
   
   <!-- #### Menu #### -->
   <?php require 'menu.php'; ?>

        <hr class="trait" style="margin: 0 auto;">
    <!-- ##### Google Maps ##### -->
    <div class="">
        <div style="margin-top:50px; margin-left:120px;float: left;">
            <h2 style="color:#28a745;">
                Infos. Perso.
            </h2>
            <hr class="trait">
        </div>
        <div style="margin-top:50px; margin-right:120px;float: right;" >
            <h6 style="color:#28a745;">
                Vous pouvez modifier :<br>
                <span class="etoile">*</span> Le N° de téléphone. <br>
                <span class="etoile">*</span> Le mot de passe. <br>
                <span class="etoile">*</span> L'Email. 
            </h6>
        </div>
    </div>
    <div style="clear: both;"></div>
    <!-- ##### Début zone de formulaire profil ##### -->
    <section class="contact-area">
        <div class="container">
            <div class="row" style="margin-top:100px">
               
                <!-- Formulaire de profil -->
                <div class="col-12 col-lg-12 col-md-12" style="margin: 0 auto;margin-bottom: 20px;">
                    <div class="contact-form">
                        <h5 align="center">
                            Certains champs ne peuvent être modifiés<span class="etoile">*</span>
                        </h5>

                        <form action="#" method="post">
                            <div class="row">
                                <div class="col-12 col-lg-6 col-md-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="text" placeholder="Nom" style="text-align: center;" readonly>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6 col-md-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="text" placeholder="Prénom" style="text-align: center;" readonly>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6 col-md-6">
                                    <div class="form-group">
                                        <input type="number" class="form-control" id="text" placeholder="Téléphone" style="text-align: center;">
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6 col-md-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="text" placeholder="Filière" style="text-align: center;" readonly>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6 col-md-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="text" placeholder="Niveau" style="text-align: center;" readonly>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6 col-md-6">
                                    <div class="form-group">
                                        <input type="email" class="form-control" id="text" placeholder="Email" style="text-align: center;">
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6 col-md-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="text" placeholder="Matricule" style="text-align: center;" readonly>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6 col-md-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="text" placeholder="Sexe" style="text-align: center;" readonly>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6 col-md-6">
                                    <div class="form-group">
                                        <input type="password" class="form-control" id="text" placeholder="Mot de passe" style="text-align: center;">
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6 col-md-6">
                                    <div class="form-group">
                                        <input type="password" class="form-control" id="text" placeholder=" Confirmer Mot de passe" style="text-align: center;">
                                    </div>
                                </div>
                                <div class="col-12">
                                    <button class="btn clever-btn w-100">
                                        Modifier
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ##### Contact Area End ##### -->

    <!-- #### footer #### -->
    <?php require 'footer.php'; ?>

    <!-- ##### Tous les scripts Js ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
    <!-- Google Maps -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAwuyLRa1uKNtbgx6xAJVmWy-zADgegA2s"></script>
    <script src="js/google-map/map-active.js"></script>
</body>

</html>