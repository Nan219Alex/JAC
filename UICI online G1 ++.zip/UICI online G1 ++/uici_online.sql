-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Mer 25 Mars 2020 à 16:07
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `uici_online`
--

-- --------------------------------------------------------

--
-- Structure de la table `administrateur`
--

CREATE TABLE IF NOT EXISTS `administrateur` (
  `ID_ADMIN` varchar(10) COLLATE utf8_bin NOT NULL,
  `NOM_ADMIN` varchar(25) COLLATE utf8_bin DEFAULT NULL,
  `PRENOM_ADMIN` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `EMAIL_ADMIN` text COLLATE utf8_bin,
  `TEL_ADMIN` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `AVATAR_ADMIN` text COLLATE utf8_bin,
  `SEXE_ADMIN` char(1) COLLATE utf8_bin DEFAULT NULL,
  `PASSWORD_ADMIN` text COLLATE utf8_bin,
  PRIMARY KEY (`ID_ADMIN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE IF NOT EXISTS `categorie` (
  `Type_categorie` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`Type_categorie`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Contenu de la table `categorie`
--

INSERT INTO `categorie` (`Type_categorie`) VALUES
('Mathématique'),
('Programmation');

-- --------------------------------------------------------

--
-- Structure de la table `chapitre`
--

CREATE TABLE IF NOT EXISTS `chapitre` (
  `ID_CHAPITRE` varchar(10) COLLATE utf8_bin NOT NULL,
  `ID_COURS` varchar(10) COLLATE utf8_bin NOT NULL,
  `TITRE_CHAPITRE` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `TYPE_CHAPITRE` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `DESCRIPTION_CHAPITRE` text COLLATE utf8_bin,
  `CONTENU_CHAPITRE` text COLLATE utf8_bin,
  PRIMARY KEY (`ID_CHAPITRE`),
  KEY `FK_CONTENIR` (`ID_COURS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `classe`
--

CREATE TABLE IF NOT EXISTS `classe` (
  `Id_classe` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`Id_classe`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Contenu de la table `classe`
--

INSERT INTO `classe` (`Id_classe`) VALUES
('Licence 1'),
('Licence 2'),
('Licence 3');

-- --------------------------------------------------------

--
-- Structure de la table `cours`
--

CREATE TABLE IF NOT EXISTS `cours` (
  `Id_cours` varchar(100) COLLATE utf8_bin NOT NULL,
  `Nom_prof` varchar(100) COLLATE utf8_bin NOT NULL,
  `Type_categorie` varchar(100) COLLATE utf8_bin NOT NULL,
  `Id_classe` varchar(100) COLLATE utf8_bin NOT NULL,
  `Id_filiere` varchar(100) COLLATE utf8_bin NOT NULL,
  `Description_cours` varchar(255) COLLATE utf8_bin NOT NULL,
  `Date_cours` date NOT NULL,
  `Heures` time NOT NULL,
  `Token` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`Id_cours`),
  KEY `Nom_prof` (`Nom_prof`,`Type_categorie`),
  KEY `Type_categorie` (`Type_categorie`),
  KEY `Id_classe` (`Id_classe`),
  KEY `Id_filiere` (`Id_filiere`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Contenu de la table `cours`
--

INSERT INTO `cours` (`Id_cours`, `Nom_prof`, `Type_categorie`, `Id_classe`, `Id_filiere`, `Description_cours`, `Date_cours`, `Heures`, `Token`) VALUES
('Algorithme', 'TRAORE', 'Programmation', 'Licence 1', 'SCIENCE INFORMATIQUE ET DU NUMERIQUE', 'Donnez les bases de la programmation', '2020-03-01', '03:45:40', 'AlgorithmeTRAORELicence 125032020062018'),
('Algèbre', 'Bally', 'Mathématique', 'Licence 2', 'SCIENCE ECONOMIQUE ET GESTION', 'Cour d''algèbre avec M BAilly', '2020-04-11', '04:41:22', 'BaillyLicence 225032020062253'),
('Analyse', 'TUO', 'Mathématique', 'Licence 2', 'SCIENCE ECONOMIQUE ET GESTION', 'Apprendre les bases des maths.', '2020-04-01', '03:48:38', 'TUOLicence 225032020062508'),
('Dev Mobile', 'Bally', 'Programmation', 'Licence 3', 'ISN-IDA', 'Apprendre à créer des application mobile.', '2020-05-15', '04:51:28', 'BallyLicence 325032020062508');

-- --------------------------------------------------------

--
-- Structure de la table `etudiant`
--

CREATE TABLE IF NOT EXISTS `etudiant` (
  `Matricule` varchar(10) COLLATE utf8_bin NOT NULL,
  `Nom` varchar(25) COLLATE utf8_bin DEFAULT NULL,
  `Prenom` varchar(150) COLLATE utf8_bin DEFAULT NULL,
  `Sexe` char(1) COLLATE utf8_bin DEFAULT NULL,
  `Telephone` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `Email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `Password` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `Avatar` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `Id_classe` varchar(100) COLLATE utf8_bin NOT NULL,
  `Id_filiere` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`Matricule`),
  KEY `Id_filiere` (`Id_filiere`),
  KEY `Id_classe` (`Id_classe`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Contenu de la table `etudiant`
--

INSERT INTO `etudiant` (`Matricule`, `Nom`, `Prenom`, `Sexe`, `Telephone`, `Email`, `Password`, `Avatar`, `Id_classe`, `Id_filiere`) VALUES
('18A0044', 'YAPI', 'Gnammien Alexandre Bérenger', 'M', '68971041', 'yapialex293@gmail.com', 'etudiant123', 'avatar', 'Licence 3', 'ISN-IDA'),
('18B0145', 'MOBIOT', 'Aby Mathieu', 'M', '01020304', 'mathieu@gmail.com', 'etudiant123', 'avatar', 'Licence 2', 'SCIENCE ECONOMIQUE ET GESTION');

-- --------------------------------------------------------

--
-- Structure de la table `exercice`
--

CREATE TABLE IF NOT EXISTS `exercice` (
  `ID_EXO` varchar(10) COLLATE utf8_bin NOT NULL,
  `ID_CHAPITRE` varchar(10) COLLATE utf8_bin NOT NULL,
  `TITRE_EXO` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `DESCRIPTION_EXO` text COLLATE utf8_bin,
  `CONTENU_EXO` text COLLATE utf8_bin,
  PRIMARY KEY (`ID_EXO`),
  KEY `FK_CONSTITUER` (`ID_CHAPITRE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `filiere`
--

CREATE TABLE IF NOT EXISTS `filiere` (
  `Id_filiere` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`Id_filiere`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Contenu de la table `filiere`
--

INSERT INTO `filiere` (`Id_filiere`) VALUES
('ISN-IDA'),
('ISN-RSI'),
('MINE ET PETROLE'),
('SCIENCE ECONOMIQUE ET GESTION'),
('SCIENCE INFORMATIQUE ET DU NUMERIQUE');

-- --------------------------------------------------------

--
-- Structure de la table `forum`
--

CREATE TABLE IF NOT EXISTS `forum` (
  `ID_FORUM` varchar(10) COLLATE utf8_bin NOT NULL,
  `MATRICULE` varchar(10) COLLATE utf8_bin NOT NULL,
  `TYPE_FORUM` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `CONTENU_FORUM` text COLLATE utf8_bin,
  `DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`ID_FORUM`),
  KEY `FK_ECHANGER` (`MATRICULE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `note`
--

CREATE TABLE IF NOT EXISTS `note` (
  `ID_NOTE` varchar(10) COLLATE utf8_bin NOT NULL,
  `MATRICULE` varchar(10) COLLATE utf8_bin NOT NULL,
  `ID_COURS` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `TYPE_NOTE` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `NOTE` decimal(4,0) DEFAULT NULL,
  `COEF_NOTE` int(11) DEFAULT NULL,
  `DATE_NOTE` datetime DEFAULT NULL,
  PRIMARY KEY (`ID_NOTE`),
  KEY `FK_AVOIR` (`MATRICULE`),
  KEY `FK_CONCERNER` (`ID_COURS`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Structure de la table `professeur`
--

CREATE TABLE IF NOT EXISTS `professeur` (
  `Nom_prof` varchar(50) COLLATE utf8_bin NOT NULL,
  `Prenom` varchar(100) COLLATE utf8_bin NOT NULL,
  `Sexe` char(1) COLLATE utf8_bin NOT NULL,
  `Email` varchar(255) COLLATE utf8_bin NOT NULL,
  `Telephone` varchar(10) COLLATE utf8_bin NOT NULL,
  `Password` varchar(255) COLLATE utf8_bin NOT NULL,
  `Avatar` varchar(50) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`Nom_prof`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Contenu de la table `professeur`
--

INSERT INTO `professeur` (`Nom_prof`, `Prenom`, `Sexe`, `Email`, `Telephone`, `Password`, `Avatar`) VALUES
('Bally', 'Bally', 'M', 'ballybally@gmail.com', '05432188', 'prof123', 'avatar'),
('TRAORE', 'issa', 'M', 'traoreeissa@gmail.com', '51206544', 'prof123', 'avatar'),
('TUO', 'David', 'M', 'Tuodavid@gmail.com', '89775632', 'prof123', 'avatar');

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `cours`
--
ALTER TABLE `cours`
  ADD CONSTRAINT `contient` FOREIGN KEY (`Id_filiere`) REFERENCES `filiere` (`Id_filiere`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `dispense` FOREIGN KEY (`Nom_prof`) REFERENCES `professeur` (`Nom_prof`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `possede` FOREIGN KEY (`Type_categorie`) REFERENCES `categorie` (`Type_categorie`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pour` FOREIGN KEY (`Id_classe`) REFERENCES `classe` (`Id_classe`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `etudiant`
--
ALTER TABLE `etudiant`
  ADD CONSTRAINT `posssede` FOREIGN KEY (`Id_filiere`) REFERENCES `filiere` (`Id_filiere`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `appartient` FOREIGN KEY (`Id_classe`) REFERENCES `classe` (`Id_classe`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `exercice`
--
ALTER TABLE `exercice`
  ADD CONSTRAINT `FK_CONSTITUER` FOREIGN KEY (`ID_CHAPITRE`) REFERENCES `chapitre` (`ID_CHAPITRE`);

--
-- Contraintes pour la table `forum`
--
ALTER TABLE `forum`
  ADD CONSTRAINT `FK_ECHANGER` FOREIGN KEY (`MATRICULE`) REFERENCES `etudiant` (`MATRICULE`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
